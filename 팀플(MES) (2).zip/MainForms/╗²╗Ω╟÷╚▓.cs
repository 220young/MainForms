﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaterCCP
{
    public partial class 생산현황 : Form
    {
        public 생산현황()
        {
            InitializeComponent();
        }
    }
}
