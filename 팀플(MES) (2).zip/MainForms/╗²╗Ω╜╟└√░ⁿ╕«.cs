﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WaterCCP
{
    public partial class 생산실적관리 : Form
    {
        public 생산실적관리()
        {
            InitializeComponent();
        }
    }
}
